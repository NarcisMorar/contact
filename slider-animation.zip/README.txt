A Pen created at CodePen.io. You can find this one at http://codepen.io/ettrics/pen/WvoRQo.

 A content slider with Material Design inspired animations and hover effects.